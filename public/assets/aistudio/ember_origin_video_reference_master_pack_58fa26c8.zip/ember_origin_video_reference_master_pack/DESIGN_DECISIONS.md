# DESIGN DECISIONS — VIDEO TO ORIGINAL WEBSITE

## Reference interpretation
The supplied video is a brief top-to-bottom scroll of a coffee website. It is low resolution, so section-level structure is more reliable than exact text transcription.

## Mapping
1. Announcement bar → compact top utility strip.
2. Navigation → original EMBER & ORIGIN wordmark, responsive links, CTA.
3. Hero → split composition with headline left and coffee visual right on desktop; stacked composition on mobile.
4. Benefit strip → 3–4 concise concept-brand benefits.
5. Story feature → photo + warm accent panel.
6. Beverage cards → four original concept drinks.
7. Coffee ritual feature → cinematic photo-led editorial panel.
8. Collection grid → 6–8 original coffee/brewing/pastry/café imagery cards.
9. Testimonial-looking area → clearly labelled sample community notes; no fake genuine reviews.
10. Newsletter → demo-only form with validation and explicit no-send confirmation.
11. Footer → links and clear fictional-brand disclaimer.

## Originality choices
- New fictional brand: EMBER & ORIGIN.
- New wordmark and original copy.
- Original palette and typographic system inspired by broad coffee editorial conventions.
- Generated or licensed images only.
- No competitor logo, copied text, or unlicensed product photos.

## Responsive choices
Desktop uses split layouts and multi-column cards. Mobile stacks the hero and story sections, uses compact navigation, and turns card rows into readable grids or swipeable lists where appropriate. All content must remain available without hover.

## Acceptance criteria
- Every mapped section appears in the intended order.
- The visual hierarchy feels coherent from hero to footer.
- Mobile and desktop layouts are intentionally designed.
- All interactive controls work.
- No fabricated real-world business details or fake reviews.
- Production build succeeds and no major runtime errors remain.
