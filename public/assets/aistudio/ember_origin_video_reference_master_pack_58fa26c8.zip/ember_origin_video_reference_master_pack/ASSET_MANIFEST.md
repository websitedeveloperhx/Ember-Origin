# ASSET MANIFEST — EMBER & ORIGIN

The user supplied a short website-scroll video, not separate image files. The video is the layout reference, not an asset library to crop and reuse.

For the finished project, record every image/model used:

| Local filename | Intended section | Source / creator | License or creation note | Attribution required? |
|---|---|---|---|---|
| `hero-coffee.webp` | Hero | Fill after asset selection | Generated concept or licensed stock only | Fill in |
| `story-atmosphere.webp` | Story feature | Fill after asset selection | Generated concept or licensed stock only | Fill in |
| `beverage-*.webp` | Beverage cards | Fill after asset selection | Generated concept or licensed stock only | Fill in |
| `ritual-feature.webp` | Coffee ritual | Fill after asset selection | Generated concept or licensed stock only | Fill in |
| `collection-*.webp` | Collection grid | Fill after asset selection | Generated concept or licensed stock only | Fill in |

Rules:
- Do not copy images from the reference website unless permission explicitly allows reuse.
- Do not falsely label generated images as real photographs of a café.
- Avoid remote hotlinking and broken URLs.
- Optimize local assets and use modern formats where supported.
- Record source, date accessed, creator, license, and attribution requirements for each stock image.
- If image rights cannot be confirmed, do not use the image.
