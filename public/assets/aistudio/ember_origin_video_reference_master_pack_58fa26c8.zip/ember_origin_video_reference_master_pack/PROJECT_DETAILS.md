# PROJECT DETAILS — VIDEO-REFERENCED ORIGINAL COFFEE WEBSITE

## Purpose
Create an original fictional coffee-brand website for a development portfolio, using the attached 4-second video as a visual guide to section order and overall composition.

## Brand
EMBER & ORIGIN — fictional portfolio concept. Not affiliated with Brewista, Roastery Coffee House, or another existing company.

## Video observations
The video appears to scroll through a desktop coffee website in this order:
1. Dark thin announcement strip.
2. Cream navigation with logo, links, and CTA.
3. Split hero: headline/copy/buttons left, coffee-cup image right.
4. Small benefit/trust strip.
5. Split story/value feature with image and terracotta panel.
6. Four beverage cards beneath a heading.
7. Dark/photo-led daily coffee ritual feature.
8. Product / editorial image grid.
9. Three review/testimonial-style cards.
10. Newsletter callout with coffee-bean decoration.
11. Multi-column footer.

The video is low-resolution and only 4 seconds long. The builder must inspect the actual attached video and verify section order and details. Do not pretend that illegible small text is readable.

## Design target
Warm cream, espresso brown, terracotta/caramel accents, restrained olive green, editorial serif headlines, clean sans-serif body font, strong imagery, intentional whitespace, premium but welcoming tone.

## Originality rules
Use the video for layout rhythm and section sequence, not to copy another business's logo, exact text, exact photography, or brand identity. Create original copy and the fictional EMBER & ORIGIN wordmark. Use generated or licensed images and document assets.

## Responsive requirements
Desktop 1440/1280; tablet 768; mobile 430/390/360. Mobile must be intentionally composed, not a scaled desktop canvas. No horizontal overflow, clipped CTAs, tiny text, or broken mobile navigation.

## Functional sections
Working header and anchors, mobile menu, menu/product cards, functional CTAs, accessible controls, demo newsletter form with explicit no-send message, footer disclaimer.

## Trust / authenticity
No fake real reviews, awards, certifications, business addresses, operating hours, phone numbers, or sourcing claims. If sample testimonials appear, label them as illustrative placeholder content. Do not create fake online ordering.

## Expected output
Complete working website, tested build, source code, local/legally reusable assets, README, asset manifest, design decisions, deployment instructions, and ZIP if supported.
