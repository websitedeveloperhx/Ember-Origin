# BUILD AND DEPLOY GUIDE

## In Google AI Studio
1. Open the Build experience.
2. Attach the supplied website-scroll video (`VN20261021_130912.mp4`) to the prompt if the interface supports video attachments.
3. Upload `MASTER_PROMPT.md` and the supporting project-detail files, or paste the full master prompt.
4. Ask the builder to implement the full app and inspect the entire page, not just the first screen.
5. Review the rendered page on desktop and mobile.
6. Ask it to fix any missing sections, overflow, broken controls, and build errors.
7. Export/download the source project or ZIP if the current interface supports it.

## Local build (if source is exported)
1. Install a supported Node.js LTS version.
2. Extract the source project.
3. Run `npm install`.
4. Run `npm run dev` to preview locally.
5. Run `npm run build`.
6. Fix build errors before publishing.

## GitHub
1. Create a new repository.
2. Upload/commit all source files and legally reusable local assets.
3. Do not commit secrets or `.env` files.
4. Include README and asset manifest.

## Vercel
1. Import the GitHub repository into Vercel.
2. Verify build command and output settings.
3. Deploy.
4. Test the deployed URL at desktop and mobile widths.
5. Confirm every image and interaction works.

## Never claim
Do not claim a successful build, test, deployment, or ZIP export unless it actually happened.
